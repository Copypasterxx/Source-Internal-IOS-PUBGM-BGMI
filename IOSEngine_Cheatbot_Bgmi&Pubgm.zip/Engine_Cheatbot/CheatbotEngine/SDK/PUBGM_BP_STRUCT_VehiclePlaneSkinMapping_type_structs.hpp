#pragma once

// PUBG MOBILE (3.0.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_VehiclePlaneSkinMapping_type.BP_STRUCT_VehiclePlaneSkinMapping_type
// 0x0018
struct FBP_STRUCT_VehiclePlaneSkinMapping_type
{
	int                                                OrginalID_0_035F8000705EAFE8164A73BF05CF7C94;             // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SkinID_1_2D869240386FF4E567A70940014D8664;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     iconURL_2_025050C0368B0D852A82EE78056E714C;               // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

