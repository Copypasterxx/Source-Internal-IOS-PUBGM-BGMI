#pragma once

// PUBG MOBILE (3.0.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum UIParticleSystem2.UIMeshProjectionMethod
enum class EUIMeshProjectionMethod : uint8_t
{
	YOZOrtho                       = 0,
	XOYOrtho                       = 1,
	YOZPerspectiveFullScreen       = 2,
	YOZPerspectiveLocal            = 3,
	UIMeshProjectionMethod_MAX     = 4
};



}

