#pragma once

// PUBG MOBILE (3.0.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_StatEvent_VNG_type.BP_STRUCT_StatEvent_VNG_type
// 0x0025
struct FBP_STRUCT_StatEvent_VNG_type
{
	struct FString                                     adjustAndroidToken_0_2B69D2C02D82C7E15A7A63F5075AEDFE;    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     adjustIOSToken_1_34A49D40116F00617E8F2AED03BA599E;        // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                id_2_66F452C07E8AB669370C7CC20C2FB044;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               unique_3_2662854074A21CCF2EDA1DF601192705;                // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

