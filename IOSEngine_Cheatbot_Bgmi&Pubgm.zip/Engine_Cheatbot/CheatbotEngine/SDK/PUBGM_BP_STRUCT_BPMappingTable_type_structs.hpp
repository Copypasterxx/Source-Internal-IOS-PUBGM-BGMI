#pragma once

// PUBG MOBILE (3.0.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_BPMappingTable_type.BP_STRUCT_BPMappingTable_type
// 0x0014
struct FBP_STRUCT_BPMappingTable_type
{
	struct FString                                     BPMapping_0_359D8E805EAA95B608F926810D8E6097;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_2_53343E0047BD3A720C3CF0DE04726144;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

