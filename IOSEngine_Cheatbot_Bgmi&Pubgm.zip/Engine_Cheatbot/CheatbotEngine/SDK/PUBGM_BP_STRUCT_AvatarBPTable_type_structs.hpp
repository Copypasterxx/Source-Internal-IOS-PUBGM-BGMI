#pragma once

// PUBG MOBILE (3.0.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_AvatarBPTable_type.BP_STRUCT_AvatarBPTable_type
// 0x0078
struct FBP_STRUCT_AvatarBPTable_type
{
	struct FString                                     CName_0_A4052DC94E7BDAA9FAD3B19A7B988D48;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     AvatarBPPath_1_891FA0534B751701E31560B16F286D8B;          // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_2_5414CFBB435533293B561394BF4A770E;                // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                IsPackage_4_4347B95845DB19587DE29887A52E05D7;             // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     Wrapper_5_663E34007B103FC200DAC514020BE042;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TemplateID_6_2887AE005383C2E84A80675E0040CD54;            // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FString                                     LobbyPath_7_17C51D006376E0D618CF05350B08C778;             // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                IsReuseWrapper_8_30F4A4006900D02E4EC7D5B60E3DD5A2;        // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
	struct FString                                     MaterialPath_9_66A36AC07FBB0355612D10BC0591FD48;          // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     MeshPath_10_2C6542406658161909A9383A04A40258;             // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

