#pragma once

// PUBG MOBILE (3.0.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_DiySuitColorConfig_type.BP_STRUCT_DiySuitColorConfig_type
// 0x0078
struct FBP_STRUCT_DiySuitColorConfig_type
{
	int                                                ItemID_1_15B6748029F10AF4167429B5070FACB4;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     BPUrl_2_1E617EC03A4F456D2C223D0106670E5C;                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Cost_3_63AB73C07271FCFF75FDA1880D66A384;                  // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ID_4_0CD2D0C023DDAD912AEEEF92052D66D4;                    // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ColorName_9_56C1CD807D19C79E1E3D3EDE01B12E25;             // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        MaskColor1_a_11_14512C805333B5405D0FD0FD032BE651;         // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        MaskColor2_a_12_6E69ECC05EBDA3E75D0FD734032BE551;         // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        MaskColor3_a_13_4882AD006A47928E5D0F3AA4032BEC51;         // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              GrayScale_f_15_0D6CFD80123EC6A658D3D8300FFAF166;          // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0064(0x0004) MISSED OFFSET
	TArray<int>                                        UIShowColor_a_16_100C6D00219953BA2ABB948401FA2891;        // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

