#pragma once

// PUBG MOBILE (3.0.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_ReddotConfig_type.BP_STRUCT_ReddotConfig_type
// 0x0030
struct FBP_STRUCT_ReddotConfig_type
{
	int                                                ID_0_78AF56C044BEFD412EE9515D060FED24;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsEliminatePrimaryReddot_1_27D0FA0036EB83B630125A6C0410D674;// 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
	struct FString                                     Name_2_5B5613C00DB5AED7351999A70FEEB235;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Weight_3_4E71ED804B30B13256D9FD060C2DF214;                // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ValidLevel_6_6FEECD801D03127225565A3C007EFE9C;            // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ValidUser_7_108A3740653B25C774ABC29402070AE2;             // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

