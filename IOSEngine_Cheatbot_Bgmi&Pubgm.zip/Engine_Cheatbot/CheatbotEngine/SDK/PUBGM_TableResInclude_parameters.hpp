#pragma once

// PUBG MOBILE (3.0.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function TableResInclude.EvoBaseMapUIMarkTableMap.TraversTable
struct UEvoBaseMapUIMarkTableMap_TraversTable_Params
{
	class UUAEDataTable*                               TableData;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Key;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function TableResInclude.EvoBaseModTableTestTableMap.TraversTable
struct UEvoBaseModTableTestTableMap_TraversTable_Params
{
	class UUAEDataTable*                               TableData;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Key;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

}

